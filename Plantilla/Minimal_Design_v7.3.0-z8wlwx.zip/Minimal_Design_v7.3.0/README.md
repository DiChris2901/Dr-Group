## Install

- Download Figma app (https://www.figma.com/downloads/).
- Open Figma app and **Drag & Drop** into app.

Learn more [guides] (https://docs.minimals.cc/figma/)

**NOTE:**

- Some illustrations may not be the same as the preview due to distribution copyright policy.
- We provide resources in _*.fig*_ file format so to use _*Dev mode*_ you need to upgrade your account to use it (https://www.figma.com/pricing/).
