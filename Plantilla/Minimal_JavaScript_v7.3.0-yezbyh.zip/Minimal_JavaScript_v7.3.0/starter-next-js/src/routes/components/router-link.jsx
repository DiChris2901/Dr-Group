import RouterLink from 'next/link';

export { RouterLink };
